create
    definer = root@localhost procedure insert_1000_comments()
BEGIN
    DECLARE i INT DEFAULT 1;
    DECLARE art_id INT;
    -- 총 246 - 124 + 1 = 123개의 게시글 ID가 있으므로, 댓글은 순환 방식으로 할당합니다.
    WHILE i <= 1000 DO
            SET art_id = 124 + ((i - 1) MOD 123);
            INSERT INTO article_comment (
                article_id,
                user_account_id,
                content,
                created_at,
                modified_at,
                created_by,
                modified_by
            )
            VALUES (
                       art_id,
                       1,
                       CONCAT('댓글 내용 ', i, ' - 예시 텍스트입니다.'),
                       NOW(),
                       NOW(),
                       'CreatedBy',
                       'ModifiedBy'
                   );
            SET i = i + 1;
        END WHILE;
END;

